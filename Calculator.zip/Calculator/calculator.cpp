﻿#include "calculator.h"
#include <QKeyEvent>
#include <QApplication>
#include <iostream>

Calculator::Calculator(QWidget *parent)
    : QWidget(parent)
{
   createWidgets();
   placeWidget();
   makeConnexions();

}
Calculator::~Calculator()
{
    delete disp;
    delete layout;
    delete buttonsLayout;
}


void Calculator::createWidgets()
{
    //Creating the layouts
    layout = new QVBoxLayout();
    layout->setSpacing(8);

    //grid layout
    buttonsLayout = new QGridLayout;


    //creating the buttons
    for(int i=0; i < 10; i++)
    {
        digits.push_back(new QPushButton(QString::number(i)));
        digits.back()->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
        digits.back()->resize(sizeHint().width(), sizeHint().height());
    }
    //enter button
    enter = new QPushButton("Enter",this);
    enter->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    enter->resize(sizeHint().width(), sizeHint().height());

    //operatiosn buttons
    operations.push_back(new QPushButton("+"));
    operations.push_back(new QPushButton("-"));
    operations.push_back(new QPushButton("*"));
    operations.push_back(new QPushButton("/"));
    operations.push_back(new QPushButton("C"));
    operations.push_back(new QPushButton("S"));



    //creating the lcd
    disp = new QLCDNumber(this);
    disp->setDigitCount(6);

    //cancel button
    cancel = new QPushButton("Cancel",this);


}

void Calculator::placeWidget()
{

    layout->addWidget(disp);
    layout->addLayout(buttonsLayout);
    layout->addWidget(enter);


    //adding the buttons
    for(int i=1; i <10; i++)
        buttonsLayout->addWidget(digits[i], (i-1)/3, (i-1)%3);


    //Adding the operations
    for(int i=0; i < 6; i++)
        buttonsLayout->addWidget(operations[ i], i, 4);


    //Adding the 0 button
    buttonsLayout->addWidget(digits[0], 3, 0);
    buttonsLayout->addWidget(cancel, 3, 1,1,2);


    setLayout(layout);
}

void Calculator::makeConnexions()
{
    //Connecting the digits
        for(int i=0; i <10; i++)
            connect(digits[i], &QPushButton::clicked,
                    this, &Calculator::newDigit);
     for(int i=0;i<6;i++)
         connect(operations[i],&QPushButton::clicked,
                 this,&Calculator::changeOperation);
     // connect operation +/-*

     connect(enter,&QPushButton::clicked,
             this,&Calculator::results);
     // connect enter button

     connect(cancel,&QPushButton::clicked,
             this,&Calculator::CancelMethod);
     //connect the Cancel button
}

void Calculator::keyPressEvent(QKeyEvent *e)
{
    int V = disp->value()*10;
    //Exiting the application by a click on space
    if( e->key() == Qt::Key_Escape)
        qApp->exit(0);
    else if( e->key() == Qt::Key_0)
    disp->display(V);
    else if( e->key() == Qt::Key_1)
        disp->display(V+1);
    else if( e->key() == Qt::Key_2)
    disp->display(V+2);
    else if( e->key() == Qt::Key_3)
       disp->display(V+3);
    else if( e->key() == Qt::Key_4)
       disp->display(V+4);
   else  if( e->key() == Qt::Key_5)
        disp->display(V+5);
    else if( e->key() == Qt::Key_6)
        disp->display(V+6);
    else if( e->key() == Qt::Key_7)
       disp->display(V+7);
   else  if( e->key() == Qt::Key_8)
       disp->display(V+8);
    else if(e->key()==Qt::Key_9)
      disp->display(V+9);

}
void Calculator::newDigit( )
{

    //Getting the identity of the button using dynamic_cast
    auto button  = dynamic_cast<QPushButton*>(sender());

    // Each button has his own digit in the text
    auto value= button->text().toInt();
    //Check if we have an operation defined
       if(operation)
       {
           //check if we have a value or not
           if(!right)
               right = new int{value};
           else
               *right = 10 * (*right) + value;
           disp->display(*right);
       }
       else
       {
           if(!left)
           {
               left = new int{value};
           }
           else
               *left = 10 * (*left) + value;

           disp->display(*left);
       }
}
void Calculator::changeOperation()
{
    //Getting the sender button
    auto button = dynamic_cast<QPushButton*>(sender());
    //Storing the operation
    operation = new QString{button->text()};
    //Initiating the right button
    right = new int{0};
        disp->display(0);
}

void Calculator::results()
{
    if (left)
       {

         if (operation->at(0)=="S")
               *left = sqrt(*left);
        else if(operation->at(0)=="C")
            *left *= *left;
           disp->display(*left);
       }
    if(left && right)
    {

        if(operation->at(0)=="-")
        {
            *left-=*right;

        }
        else if(operation->at(0)=="+")
        {
            *left+=*right;

        }
        if(operation->at(0)=="/")
        {
            *left/=*right;
        }
        if(operation->at(0)=="*")
        {
            *left *= *right;

        }

     disp->display(*left);
    }


}
void Calculator::CancelMethod()
{
right =NULL;
left= NULL;
operation= NULL;
disp->display(0);
}
